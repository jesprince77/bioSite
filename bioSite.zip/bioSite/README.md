# bioSite
Bio of founder of Planet-Possibility
# CSD 340 Web Development with HTML and CSS
## Contributors
- Michael McGee
- Prince Wallace
